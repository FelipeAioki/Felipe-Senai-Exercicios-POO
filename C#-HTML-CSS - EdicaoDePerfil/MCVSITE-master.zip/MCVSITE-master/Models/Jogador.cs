namespace MVC_EPLAYERS.Models
{
    public class Jogador
    {
        public int IdJogador { get; set; }
        public string Nome { get; set; }
        public string IdEquipe { get; set; }
    }
}