namespace MVC_EPLAYERS.Models
{
    public class Noticia
    {
        public int IdNoticia { get; set; }
        public string Nome { get; set; }
        public string Imagem { get; set; }
    }
}