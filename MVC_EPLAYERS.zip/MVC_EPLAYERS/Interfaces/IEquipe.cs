using System.Collections.Generic;
using MVC_EPLAYERS.Models;

namespace MVC_EPLAYERS.Interfaces
{
    public interface IEquipe
    {
        void Create (Equipe e);

        List<Equipe> ReadAll();
        void Update (Equipe e);
        void Delete (int IdEquipe);
    }
}