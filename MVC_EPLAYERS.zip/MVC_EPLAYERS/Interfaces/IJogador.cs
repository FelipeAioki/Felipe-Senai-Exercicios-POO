using System.Collections.Generic;
using MVC_EPLAYERS.Models;

namespace MVC_EPLAYERS.Interfaces
{
    public interface IJogador
    {
        void Create(Jogador jogador);
        List<Jogador> ReadAll();
        void Update(Jogador jogador);
        void Delete(int IdJogador);
    }
}