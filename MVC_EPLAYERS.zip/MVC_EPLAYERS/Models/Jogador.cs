using System.Collections.Generic;
using System.IO;
using MVC_EPLAYERS.Interfaces;

namespace MVC_EPLAYERS.Models
{
public class Jogador : EPlayersBase, IJogador
{
    public int IdJogador { get; set; }
    public string Nome { get; set; }
    public int IdEquipe { get; set; }
    public string Email { get; set; }
    public string Senha { get; set; }

public const string PATH = "Database/Jogador.csv";

    public Jogador()
    {
        CreateFolderAndFile(PATH);
    }

    //Métopos implantados pela interface "IJogador"
    //Método para criar Jogador
    public void Create(Jogador jogador)
    {
        string[] linha = { PrepararLinha(jogador) };
        File.AppendAllLines(PATH, linha);
    }

    // Prepara a linha para a estrutura do objeto Jogador
    private string PrepararLinha(Jogador j)
    {
        return $"{j.IdJogador};{j.Nome};{j.Email};{j.Senha}";
    }

    //Método para Ler os jogadores cadastrados

    public List<Jogador> ReadAll()
    {
        List<Jogador> jogadores = new List<Jogador>();
        string[] linhas = File.ReadAllLines(PATH);

        foreach (var item in linhas)
        {
            string[] linha = item.Split(";");

            Jogador jogador   = new Jogador();
            jogador.IdJogador = int.Parse(linha[0]);
            jogador.Nome      = linha[1];
            jogador.Email     = linha[2];
            jogador.Senha     = linha[3];

            jogadores.Add(jogador);
        }
        return jogadores;
    }

    //Método para ler o CSV
    public void Update(Jogador jogador)
    {
        List<string> linhas = ReadAllLinesCSV(PATH);
        linhas.RemoveAll(x => x.Split(";")[0] == jogador.IdJogador.ToString());
        linhas.Add( PrepararLinha(jogador) );                        
        RewriteCSV(PATH, linhas); 
    }

    //Método para excluir um jogador
    public void Delete(int IdJogador)
    {
        List<string> linhas = ReadAllLinesCSV(PATH);
        linhas.RemoveAll(x => x.Split(";")[0] == IdJogador.ToString());                        
        RewriteCSV(PATH, linhas);
    }
}

}