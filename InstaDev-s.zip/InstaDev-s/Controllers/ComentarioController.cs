using Microsoft.AspNetCore.Mvc;

namespace InstaDev_s.Controllers
{
    public class ComentarioController : Controller
    {
        
    }
}