using InstaDev_s.Models;
using Microsoft.AspNetCore.Mvc;

namespace InstaDev_s.Controllers
{
    public class PublicacaoController
    {

        Publicacao publicacao = new Publicacao();



    }
}